//
//  LoginViewController.swift
//  ChatApp
//
//  Created by Waleed Waheed Khan on 5/28/20.
//  Copyright © 2020 Waleed Waheed Khan. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore




struct User {
    var id: String?
    let name: String
    
    init(name: String) {
        id = nil
        self.name = name
    }
    
    init?(data: [String:Any]) {
        
        guard let id = data["id"] as? String else {
            return nil
        }
        guard let name = data["userName"] as? String else{
            return nil
        }
        self.id = id
        self.name = name
    }
    
    init?(document: QueryDocumentSnapshot) {
        let data = document.data()
        
        guard let name = data["userName"] as? String else {
            return nil
        }
        
        id = document.documentID
        self.name = name
    }
}

extension User: Dictionary {
    
    var dictionary: [String : Any] {
        var data = ["userName": name]
        
        if let id = id {
            data["id"] = id
        }
        
        return data
    }
    
}

class LoginViewController: UIViewController {
    
    private var createNewUserAlertController: UIAlertController?
    
    private let db = Firestore.firestore()
    
    private var reference: CollectionReference {
        return db.collection("user")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = .white
        self.title = "Login"
        openAlertView()
        
    }
    
}


extension LoginViewController {
    func openAlertView() {
        let ac = UIAlertController(title: "Create a new user", message: nil, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        ac.addTextField { field in
            field.addTarget(self, action: #selector(self.textFieldDidChange(_:)), for: .editingChanged)
            field.enablesReturnKeyAutomatically = true
            field.autocapitalizationType = .words
            field.clearButtonMode = .whileEditing
            field.placeholder = "Enter Username"
            field.returnKeyType = .done
            field.tintColor = .systemBlue
        }
        
        let createAction = UIAlertAction(title: "SignUp", style: .default, handler: { _ in
            self.createUser()
        })
        createAction.isEnabled = false
        ac.addAction(createAction)
        ac.preferredAction = createAction
        
        present(ac, animated: true) {
            ac.textFields?.first?.becomeFirstResponder()
        }
        createNewUserAlertController = ac
    }
    
    @objc private func textFieldDidChange(_ field: UITextField) {
        guard let ac = createNewUserAlertController else {
            return
        }
        
        ac.preferredAction?.isEnabled = field.hasText
    }
    
    func createUser() {
        guard let ac = createNewUserAlertController else {
            return
        }
        
        guard let text = ac.textFields?.first?.text else {
            return
        }
        var found = false
        
        let alert = UIAlertController(title: nil, message: "loading...", preferredStyle: .alert)
        
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.style = UIActivityIndicatorView.Style.medium
        loadingIndicator.startAnimating();
        
        alert.view.addSubview(loadingIndicator)
        present(alert, animated: true, completion: nil)
        
        reference.getDocuments { querySnapshot, error in
            guard let snapshot = querySnapshot else {
                print("Error listening for user updates: \(error?.localizedDescription ?? "No error")")
                return
            }
            
            snapshot.documentChanges.forEach { change in
                let user = User(document: change.document)
                if user?.name == text {
                    found = true
                    let defaults = UserDefaults.standard
                    defaults.set(user?.dictionary, forKey: "user")
                    let vc = UINavigationController(rootViewController: ChatRoomViewController(user!))
                    self.dismiss(animated: false, completion: nil)
                    vc.modalPresentationStyle = .overFullScreen
                    vc.modalTransitionStyle = .flipHorizontal
                    self.navigationController?.present(vc, animated: true, completion: nil)
                    return
                }
            }
            if !found {
                var user = User(name: text)
                
                var ref: DocumentReference? = nil
                ref = self.reference.addDocument(data: user.dictionary) { error in
                    if let e = error {
                        print("Error saving user: \(e.localizedDescription)")
                    }
                    user.id = ref?.documentID
                    let defaults = UserDefaults.standard
                    defaults.set(user.dictionary, forKey: "user")
                    let vc = UINavigationController(rootViewController: ChatRoomViewController(user))
                    self.dismiss(animated: false, completion: nil)
                    vc.modalPresentationStyle = .overFullScreen
                    vc.modalTransitionStyle = .flipHorizontal
                    self.navigationController?.present(vc, animated: true, completion: nil)
                    return
                }
            }
        }
    }
    
}
