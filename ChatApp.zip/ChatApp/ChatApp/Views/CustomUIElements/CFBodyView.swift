//
//  CFBodyView.swift
//  ChatWithoutStoryBoard
//
//  Created by Waleed Waheed Khan on 5/9/20.
//  Copyright © 2020 Waleed Waheed Khan. All rights reserved.
//

import UIKit

class CFBodyView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setup()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init(backgroundColor: UIColor) {
        super.init(frame: .zero)
        
        self.backgroundColor = backgroundColor
        setup()
    }
}
extension CFBodyView {
    private func setup() {
        translatesAutoresizingMaskIntoConstraints = false
    }
}
