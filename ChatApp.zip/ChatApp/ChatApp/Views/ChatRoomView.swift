//
//  ChatRoomView.swift
//  ChatWithoutStoryBoard
//
//  Created by Waleed Waheed Khan on 5/26/20.
//  Copyright © 2020 Waleed Waheed Khan. All rights reserved.
//

import Foundation

import UIKit

class ChatRoomView: UIView {
    
    var chatRoomViewController: ChatRoomViewController? {
        didSet {
            createNewMessageButton.addTarget(chatRoomViewController, action: #selector(ChatRoomViewController.createNewMessage), for: .touchUpInside)
            creatGroupButton.addTarget(chatRoomViewController, action: #selector(ChatRoomViewController.creatGroupButton), for: .touchUpInside)
        }
    }
    
    let tableView = UITableView()
    
    let topView = CFBodyView()
    let userInfoView = CFBodyView()
    let bottomBorderView = CFBodyView(backgroundColor: .white)
    let userTypeView = CFBodyView(backgroundColor: .systemPink)
    let userImageView = CFBodyView(backgroundColor: .lightGray)
    
    let bottomView: CFBodyView = {
        let color = UIColor(red: 234/255.0, green: 236/255.0, blue: 238/255.0, alpha: 1.0)
        let view = CFBodyView(backgroundColor: color)
        return view
    }()
    
    let userTypeText = CFBodyLabel()
    let usernameText = CFBodyLabel()
    let membersText = CFBodyLabel()
    
    let createNewMessageButton = CFBodyButton(title: "New Message", backgroundColor: .clear, titleColor: .systemBlue)
    let creatGroupButton = CFBodyButton(title: "Creat Group", backgroundColor: .clear, titleColor: .black)
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = .systemBackground
        
        setupScreen()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension ChatRoomView {
    private func setupTopView() {
        addSubview(topView)
        topView.backgroundColor = .systemRed
        NSLayoutConstraint.activate([
            topView.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 0),
            topView.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: 0),
            topView.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: 0),
            topView.heightAnchor.constraint(equalToConstant: 70)
        ])
        
        topView.addSubview(userTypeText)
        
        userTypeText.text = "Chat Room"
        userTypeText.textColor = .white
        userTypeText.textAlignment = .center
        userTypeText.font = UIFont.systemFont(ofSize: 20.0, weight: .bold)
        userTypeText.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            userTypeText.centerXAnchor.constraint(equalTo: topView.centerXAnchor, constant: 0),
            userTypeText.centerYAnchor.constraint(equalTo: topView.centerYAnchor, constant: 0)
        ])
        
    }
    
    private func setupTableView() {
        addSubview(tableView)
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 0),
            tableView.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: 0),
            tableView.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: 0)
        ])
    }
    
    private func setupBottomBorderView() {
        addSubview(bottomBorderView)
        
        bottomBorderView.layer.borderWidth = 1.0
        bottomBorderView.layer.cornerRadius = 5.0
        bottomBorderView.layer.borderColor = UIColor.lightGray.cgColor
        
        NSLayoutConstraint.activate([
            bottomBorderView.topAnchor.constraint(equalTo: tableView.bottomAnchor, constant: 10),
            bottomBorderView.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: 10),
            bottomBorderView.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -10),
            bottomBorderView.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -10),
            bottomBorderView.heightAnchor.constraint(equalToConstant: 60)
        ])
        setupBottomView()
    }
    
    private func setupBottomView() {
        bottomBorderView.addSubview(bottomView)
        
        bottomView.layer.cornerRadius = 2.5
        
        NSLayoutConstraint.activate([
            bottomView.topAnchor.constraint(equalTo: bottomBorderView.topAnchor, constant: 5),
            bottomView.leadingAnchor.constraint(equalTo: bottomBorderView.leadingAnchor, constant: 5),
            bottomView.trailingAnchor.constraint(equalTo: bottomBorderView.trailingAnchor, constant: -5),
            bottomView.bottomAnchor.constraint(equalTo: bottomBorderView.bottomAnchor, constant: -5)
        ])
        newGroup()
        newChat()
    }
    
    private func newGroup() {
        bottomView.addSubview(creatGroupButton)
        
        NSLayoutConstraint.activate([
            creatGroupButton.leadingAnchor.constraint(equalTo: bottomView.leadingAnchor, constant: 0),
            creatGroupButton.bottomAnchor.constraint(equalTo: bottomView.bottomAnchor, constant: 0),
            creatGroupButton.heightAnchor.constraint(equalToConstant: 50),
        ])
    }
    
    private func newChat() {
        bottomView.addSubview(createNewMessageButton)
        
        NSLayoutConstraint.activate([
            createNewMessageButton.trailingAnchor.constraint(equalTo: bottomView.trailingAnchor, constant: 0),
            createNewMessageButton.bottomAnchor.constraint(equalTo: bottomView.bottomAnchor, constant: 0),
            createNewMessageButton.heightAnchor.constraint(equalToConstant: 50),
        ])
    }
    
    
    private func setupScreen() {
        setupTopView()
        setupTableView()
        setupBottomBorderView()
    }
    
    private func setPadding(textField: UITextField) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: self.frame.height))
        textField.leftView = paddingView
        textField.rightView = paddingView
        textField.leftViewMode = .always
        textField.rightViewMode = .always
    }
}
