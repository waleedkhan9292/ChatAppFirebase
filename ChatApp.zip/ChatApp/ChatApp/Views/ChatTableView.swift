//
//  ChatTableView.swift
//  ChatWithoutStoryBoard
//
//  Created by Waleed Waheed Khan on 5/8/20.
//  Copyright © 2020 Waleed Waheed Khan. All rights reserved.
//

import UIKit

class ChatTableView: UIView {
    
    var viewController: ViewController? {
        didSet {
            sendButton.addTarget(viewController, action: #selector(ViewController.sendMessage), for: .touchUpInside)
        }
    }
    let tableView = UITableView()
    
    let topView = CFBodyView()
    let userInfoView = CFBodyView()
    let bottomBorderView = CFBodyView(backgroundColor: .white)
    let userTypeView = CFBodyView(backgroundColor: .systemPink)
    let userImageView = CFBodyView(backgroundColor: .lightGray)
    
    let bottomView: CFBodyView = {
        let color = UIColor(red: 234/255.0, green: 236/255.0, blue: 238/255.0, alpha: 1.0)
        let view = CFBodyView(backgroundColor: color)
        return view
    }()
    
    let userTypeText = CFBodyLabel()
    let usernameText = CFBodyLabel()
    let membersText = CFBodyLabel()

    let sendButton = CFBodyButton(title: "Send", backgroundColor: .clear, titleColor: .systemBlue)

    let messageTextField = CFBodyTextField(placeHolder: "Type")
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = .systemBackground
        
        setupScreen()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}

extension ChatTableView {
    private func setupTopView() {
        addSubview(topView)
        topView.backgroundColor = .systemRed
        NSLayoutConstraint.activate([
            topView.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 0),
            topView.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: 0),
            topView.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: 0),
            topView.heightAnchor.constraint(equalToConstant: 70)
        ])
        
        topView.addSubview(userTypeText)
        
        userTypeText.text = ""
        userTypeText.textColor = .white
        userTypeText.textAlignment = .center
        userTypeText.font = UIFont.systemFont(ofSize: 20.0, weight: .bold)
        userTypeText.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            userTypeText.centerXAnchor.constraint(equalTo: topView.centerXAnchor, constant: 0),
            userTypeText.centerYAnchor.constraint(equalTo: topView.centerYAnchor, constant: 0)
        ])
    }
    
    private func setImageView() {
        topView.addSubview(userImageView)
        
        userImageView.layer.cornerRadius = 25.0
        
        NSLayoutConstraint.activate([
            userImageView.centerYAnchor.constraint(equalTo: topView.centerYAnchor, constant: 0),
            userImageView.leadingAnchor.constraint(equalTo: topView.leadingAnchor, constant: 10),
            userImageView.heightAnchor.constraint(equalToConstant: 50.0),
            userImageView.widthAnchor.constraint(equalToConstant: 50.0)
        ])
        setUserTypeView()
    }
    
    private func setUserTypeView() {
        topView.addSubview(userTypeView)
        
        userTypeView.layer.cornerRadius = 10.0
        
        NSLayoutConstraint.activate([
            userTypeView.centerXAnchor.constraint(equalTo: userImageView.centerXAnchor, constant: 0),
            userTypeView.bottomAnchor.constraint(equalTo: topView.bottomAnchor, constant: 0),
            userTypeView.heightAnchor.constraint(equalToConstant: 20.0)
        ])
        setUserTypeText()
    }
    
    private func setUserTypeText() {
        userTypeView.addSubview(userTypeText)
        
        userTypeText.text = "Admin"
        userTypeText.textColor = .white
        userTypeText.textAlignment = .center
        userTypeText.font = UIFont.systemFont(ofSize: 11.0, weight: .regular)
        userTypeText.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            userTypeText.topAnchor.constraint(equalTo: userTypeView.topAnchor, constant: 0),
            userTypeText.leadingAnchor.constraint(equalTo: userTypeView.leadingAnchor, constant: 10),
            userTypeText.trailingAnchor.constraint(equalTo: userTypeView.trailingAnchor, constant: -10),
            userTypeText.bottomAnchor.constraint(equalTo: userTypeView.bottomAnchor, constant: 0)
        ])
    }
    
    
    private func setUserInfoView() {
        topView.addSubview(userInfoView)
        
        NSLayoutConstraint.activate([
            userInfoView.centerYAnchor.constraint(equalTo: userImageView.centerYAnchor, constant: 0),
            userInfoView.leadingAnchor.constraint(equalTo: userImageView.trailingAnchor, constant: 10),
            userInfoView.trailingAnchor.constraint(equalTo: topView.trailingAnchor, constant: -10)
        ])
        setUsernameText()
    }
    
    private func setUsernameText() {
        userInfoView.addSubview(usernameText)
        
        usernameText.text = "Meeting With Developers"
        usernameText.textColor = .darkGray
        usernameText.textAlignment = .left
        usernameText.numberOfLines = 2
        usernameText.font = UIFont.systemFont(ofSize: 16.0, weight: .regular)
        
        NSLayoutConstraint.activate([
            usernameText.topAnchor.constraint(equalTo: userInfoView.topAnchor, constant: 0),
            usernameText.leadingAnchor.constraint(equalTo: userInfoView.leadingAnchor, constant: 0),
            usernameText.trailingAnchor.constraint(equalTo: userInfoView.trailingAnchor, constant: 0)
        ])
        setMembersText()
    }
    
    private func setMembersText() {
        userInfoView.addSubview(membersText)
        
        membersText.text = "Vilma, Haward Barhs, Robby Joni"
        membersText.textColor = .lightGray
        membersText.layer.cornerRadius = 10.0
        membersText.textAlignment = .left
        usernameText.numberOfLines = 1
        membersText.font = UIFont.systemFont(ofSize: 14.0, weight: .regular)
        
        NSLayoutConstraint.activate([
            membersText.topAnchor.constraint(equalTo: usernameText.bottomAnchor, constant: 0),
            membersText.leadingAnchor.constraint(equalTo: userInfoView.leadingAnchor, constant: 0),
            membersText.trailingAnchor.constraint(equalTo: userInfoView.trailingAnchor, constant: 0),
            membersText.bottomAnchor.constraint(equalTo: userInfoView.bottomAnchor, constant: 0),
            membersText.heightAnchor.constraint(equalToConstant: 20.0)
        ])
    }
    
    private func setupTableView() {
        addSubview(tableView)
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
        tableView.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 0),
            tableView.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: 0),
            tableView.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: 0)
        ])
    }
    
    private func setupBottomBorderView() {
        addSubview(bottomBorderView)
        
        bottomBorderView.layer.borderWidth = 1.0
        bottomBorderView.layer.cornerRadius = 5.0
        bottomBorderView.layer.borderColor = UIColor.lightGray.cgColor
        
        NSLayoutConstraint.activate([
            bottomBorderView.topAnchor.constraint(equalTo: tableView.bottomAnchor, constant: 10),
            bottomBorderView.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: 10),
            bottomBorderView.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -10),
            bottomBorderView.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -10),
            bottomBorderView.heightAnchor.constraint(equalToConstant: 60)
        ])
        setupBottomView()
    }
    
    private func setupBottomView() {
        bottomBorderView.addSubview(bottomView)
        
        bottomView.layer.cornerRadius = 2.5
//        bottomView.backgroundColor = UIColor(red: 234/255.0, green: 236/255.0, blue: 238/255.0, alpha: 1.0)
        
        NSLayoutConstraint.activate([
            bottomView.topAnchor.constraint(equalTo: bottomBorderView.topAnchor, constant: 5),
            bottomView.leadingAnchor.constraint(equalTo: bottomBorderView.leadingAnchor, constant: 5),
            bottomView.trailingAnchor.constraint(equalTo: bottomBorderView.trailingAnchor, constant: -5),
            bottomView.bottomAnchor.constraint(equalTo: bottomBorderView.bottomAnchor, constant: -5)
        ])
        setTextField()
    }
    
    private func setTextField() {
        bottomView.addSubview(messageTextField)
        
        setPadding(textField: messageTextField)
        
        NSLayoutConstraint.activate([
            messageTextField.topAnchor.constraint(equalTo: bottomView.topAnchor, constant: 0),
            messageTextField.leadingAnchor.constraint(equalTo: bottomView.leadingAnchor, constant: 0),
            messageTextField.bottomAnchor.constraint(equalTo: bottomView.bottomAnchor, constant: 0)
        ])
        setSendButton()
    }
    
    private func setSendButton() {
        bottomView.addSubview(sendButton)
        
        NSLayoutConstraint.activate([
            sendButton.leadingAnchor.constraint(equalTo: messageTextField.trailingAnchor, constant: 0),
            sendButton.trailingAnchor.constraint(equalTo: bottomView.trailingAnchor, constant: 0),
            sendButton.bottomAnchor.constraint(equalTo: bottomView.bottomAnchor, constant: 0),
            sendButton.heightAnchor.constraint(equalToConstant: 50),
            sendButton.widthAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    
    private func setupScreen() {
        setupTopView()
        setupTableView()
        setupBottomBorderView()
    }
    
    private func setPadding(textField: UITextField) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: self.frame.height))
        textField.leftView = paddingView
        textField.rightView = paddingView
        textField.leftViewMode = .always
        textField.rightViewMode = .always
    }
}
