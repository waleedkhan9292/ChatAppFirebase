//
//  ChatRoomCell.swift
//  ChatWithoutStoryBoard
//
//  Created by Waleed Waheed Khan on 5/26/20.
//  Copyright © 2020 Waleed Waheed Khan. All rights reserved.
//

import UIKit

class ChatRoomCell: UITableViewCell {
    
    
    let mainView = CFBodyView()
    let maincontentView = CFBodyView()
    let userInfoView = CFBodyView()
    let userImageView = CFBodyView(backgroundColor: .lightGray)
    let userNameView = CFBodyView()
    let messageView = CFBodyView(backgroundColor: .systemIndigo)
    let messageBorderView = CFBodyView(backgroundColor: .white)
    let timeView = CFBodyView()
    
    let usernameLabel = CFBodyLabel()
    let messageText = CFBodyLabel()
    let timeText = CFBodyLabel()
    
    var chatMessage: ChatRoom! {
        didSet {
            messageText.text = "Static text"
            usernameLabel.text = chatMessage.name
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupScreen()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
}

extension ChatRoomCell {
    private func setupContentView() {
        addSubview(maincontentView)
        
        NSLayoutConstraint.activate([
            maincontentView.topAnchor.constraint(equalTo: topAnchor, constant: 0),
            maincontentView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 0),
            maincontentView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: 0),
            maincontentView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: 0)
        ])
    }
    
    private func setupCellMainView() {
        maincontentView.addSubview(mainView)
        
        NSLayoutConstraint.activate([
            mainView.topAnchor.constraint(equalTo: maincontentView.topAnchor, constant: 0),
            mainView.leadingAnchor.constraint(equalTo: maincontentView.leadingAnchor, constant: 10),
            mainView.trailingAnchor.constraint(lessThanOrEqualTo: maincontentView.trailingAnchor, constant: -10),
            mainView.bottomAnchor.constraint(equalTo: maincontentView.bottomAnchor, constant: 0)
        ])
    }
    
    private func setupUserInfoView() {
        mainView.addSubview(userInfoView)
        
        NSLayoutConstraint.activate([
            userInfoView.topAnchor.constraint(equalTo: mainView.topAnchor, constant: 0),
            userInfoView.leadingAnchor.constraint(equalTo: mainView.leadingAnchor, constant: 0),
            userInfoView.trailingAnchor.constraint(equalTo: mainView.trailingAnchor, constant: 0),
            userInfoView.bottomAnchor.constraint(equalTo: messageBorderView.topAnchor, constant: 20),
            userInfoView.heightAnchor.constraint(equalToConstant: 50)
        ])
        setupUserImageView()
    }
    
    private func setupUserImageView() {
        userInfoView.addSubview(userImageView)
        
        userImageView.layer.cornerRadius = 25.0
        
        NSLayoutConstraint.activate([
            userImageView.topAnchor.constraint(equalTo: userInfoView.topAnchor, constant: 0),
            userImageView.leadingAnchor.constraint(equalTo: userInfoView.leadingAnchor, constant: 20),
            userImageView.bottomAnchor.constraint(equalTo: userInfoView.bottomAnchor, constant: 0),
            userImageView.widthAnchor.constraint(equalToConstant: 50)
        ])
        setupUserNameView()
        
    }
    
    private func setupUserNameView() {
        userInfoView.addSubview(userNameView)
        
        NSLayoutConstraint.activate([
            userNameView.centerYAnchor.constraint(equalTo: userImageView.centerYAnchor, constant: -5),
            userNameView.leadingAnchor.constraint(equalTo: userImageView.trailingAnchor, constant: 0),
            userNameView.trailingAnchor.constraint(equalTo: userInfoView.trailingAnchor, constant: 0)
        ])
        setupUserNameLabel()
    }
    
    private func setupUserNameLabel() {
        userNameView.addSubview(usernameLabel)
        usernameLabel.font = UIFont.systemFont(ofSize: 14.0, weight: .regular)
        
        NSLayoutConstraint.activate([
            usernameLabel.topAnchor.constraint(equalTo: userNameView.topAnchor, constant: 0),
            usernameLabel.leadingAnchor.constraint(equalTo: userNameView.leadingAnchor, constant: 5),
            usernameLabel.trailingAnchor.constraint(equalTo: userNameView.trailingAnchor, constant: 5),
            usernameLabel.bottomAnchor.constraint(equalTo: userNameView.bottomAnchor, constant: 0)
        ])
    }
    
    private func setupMessageBorderView() {
        
        mainView.addSubview(messageBorderView)
        
        messageBorderView.layer.borderWidth = 2.0
        messageBorderView.layer.cornerRadius = 10.0
        messageBorderView.layer.borderColor = UIColor.systemIndigo.cgColor
        
        NSLayoutConstraint.activate([
            messageBorderView.leadingAnchor.constraint(equalTo: mainView.leadingAnchor, constant: 0),
            messageBorderView.trailingAnchor.constraint(equalTo: mainView.trailingAnchor, constant: 0)
        ])
        setupTextMessageView()
    }
    
    private func setupTextMessageView() {
        messageBorderView.addSubview(messageView)
        
        messageView.layer.cornerRadius = 5.0
        
        NSLayoutConstraint.activate([
            messageView.topAnchor.constraint(equalTo: messageBorderView.topAnchor, constant: 5),
            messageView.leadingAnchor.constraint(equalTo: messageBorderView.leadingAnchor, constant: 5),
            messageView.trailingAnchor.constraint(equalTo: messageBorderView.trailingAnchor, constant: -5),
            messageView.bottomAnchor.constraint(equalTo: messageBorderView.bottomAnchor, constant: -5)
        ])
        setupMessageText()
    }
    
    private func setupMessageText() {
        messageView.addSubview(messageText)
        messageText.numberOfLines = 0
        timeText.font = UIFont.systemFont(ofSize: 14.0, weight: .regular)
        messageText.textColor = .white
        
        NSLayoutConstraint.activate([
            messageText.topAnchor.constraint(equalTo: messageView.topAnchor, constant: 25),
            messageText.leadingAnchor.constraint(equalTo: messageView.leadingAnchor, constant: 15),
            messageText.trailingAnchor.constraint(equalTo: messageView.trailingAnchor, constant: -15),
            messageText.bottomAnchor.constraint(equalTo: messageView.bottomAnchor, constant: -15)
        ])
    }
    
    private func setupTimeView() {
        mainView.addSubview(timeView)
        
        NSLayoutConstraint.activate([
            timeView.topAnchor.constraint(equalTo: messageBorderView.bottomAnchor, constant: 5),
            timeView.leadingAnchor.constraint(equalTo: mainView.leadingAnchor, constant: 20),
            timeView.trailingAnchor.constraint(equalTo: mainView.trailingAnchor, constant: 0),
            timeView.bottomAnchor.constraint(equalTo: mainView.bottomAnchor, constant: 0),
            timeView.heightAnchor.constraint(equalToConstant: 20.0)
            
        ])
        setupTimeText()
    }
    
    private func setupTimeText() {
        timeView.addSubview(timeText)
        timeText.numberOfLines = 0
        timeText.text = "08:00 PM"
        timeText.textColor = .darkGray
        timeText.font = UIFont.systemFont(ofSize: 11.0, weight: .regular)
        
        NSLayoutConstraint.activate([
            timeText.topAnchor.constraint(equalTo: timeView.topAnchor, constant: 0),
            timeText.leadingAnchor.constraint(equalTo: timeView.leadingAnchor, constant: 0),
            timeText.trailingAnchor.constraint(equalTo: timeView.trailingAnchor, constant: 0),
            timeText.bottomAnchor.constraint(equalTo: timeView.bottomAnchor, constant: 0)
        ])
    }
    private func setupScreen() {
        setupContentView()
        setupCellMainView()
        setupMessageBorderView()
        setupUserInfoView()
        setupTimeView()
    }
}

