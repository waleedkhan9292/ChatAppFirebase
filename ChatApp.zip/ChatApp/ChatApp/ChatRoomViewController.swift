//
//  ChatRoomViewController.swift
//  ChatWithoutStoryBoard
//
//  Created by Waleed Waheed Khan on 5/26/20.
//  Copyright © 2020 Waleed Waheed Khan. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

protocol Dictionary {
    var dictionary: [String: Any] { get }
}

struct ChatRoom {
    var id: String?
    let name: String
    var groupUsers: String?
    
    init(name: String) {
        id = nil
        groupUsers = nil
        self.name = name
    }
    
    init(name: String, groupUsers: String) {
        id = nil
        self.name = name
        self.groupUsers = groupUsers
    }
    
    
    init?(document: QueryDocumentSnapshot) {
        let data = document.data()
        
        guard let name = data["name"] as? String else {
            return nil
        }
        
        groupUsers = nil
        if let groupUsers = data["groupUsers"] as? String {
            self.groupUsers = groupUsers
        }
    
        id = document.documentID
        self.name = name
    }
}

extension ChatRoom: Dictionary {
    
    var dictionary: [String : Any] {
        var data = ["name": name]
        
        if let id = id {
            data["id"] = id
        }
        if let groupUsers = groupUsers {
            data["groupUsers"] = groupUsers
        }
        
        return data
    }
    
}

extension ChatRoom: Comparable {
    
    static func == (lhs: ChatRoom, rhs: ChatRoom) -> Bool {
        return lhs.id == rhs.id
    }
    
    static func < (lhs: ChatRoom, rhs: ChatRoom) -> Bool {
        return lhs.name < rhs.name
    }
    
}

class ChatRoomViewController: UIViewController {
    
    private let db = Firestore.firestore()
    private var createNewMessageAlertController: UIAlertController?
    
    private var reference: CollectionReference?
    
    private var chatRoomListener: ListenerRegistration?
    
    deinit {
        chatRoomListener?.remove()
    }
    
    var user: User?
    
    let chatTableView = ChatRoomView()
    
    var chatMessages = [ChatRoom]()
    
    override func loadView() {
        view = chatTableView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setTableView()
        chatTableView.chatRoomViewController = self
        self.title = "Chat Room"
        guard let id = user?.id else {
            return
        }
        reference = db.collection(["user", id, "channel"].joined(separator: "/"))
        chatRoomListener = reference?.addSnapshotListener { querySnapshot, error in
            guard let snapshot = querySnapshot else {
                print("Error listening for chat room updates: \(error?.localizedDescription ?? "No error")")
                return
            }
            
            snapshot.documentChanges.forEach { change in
                self.handleDocumentChange(change)
            }
        }
    }
    
    init(_ user: User) {
        super.init(nibName: nil, bundle: nil)
        self.user = user
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension ChatRoomViewController {
    func setTableView() {
        chatTableView.tableView.dataSource = self
        chatTableView.tableView.delegate = self
        chatTableView.tableView.separatorStyle = .none
        
        chatTableView.tableView.register(ChatRoomCell.self, forCellReuseIdentifier: "chatRoomCell")
    }
    
    @objc func createNewMessage() {
        let ac = UIAlertController(title: "Create a new Message", message: nil, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        ac.addTextField { field in
            field.addTarget(self, action: #selector(self.textFieldDidChange(_:)), for: .editingChanged)
            field.enablesReturnKeyAutomatically = true
            field.autocapitalizationType = .words
            field.clearButtonMode = .whileEditing
            field.placeholder = "Username"
            field.returnKeyType = .done
            field.tintColor = .systemBlue
        }
        
        let createAction = UIAlertAction(title: "Create", style: .default, handler: { _ in
            self.createChatRoom()
        })
        createAction.isEnabled = false
        ac.addAction(createAction)
        ac.preferredAction = createAction
        
        present(ac, animated: true) {
            ac.textFields?.first?.becomeFirstResponder()
        }
        createNewMessageAlertController = ac
    }
    @objc func creatGroupButton() {
        let ac = UIAlertController(title: "Create a new group", message: nil, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        ac.addTextField { field in
            field.addTarget(self, action: #selector(self.textFieldDidChange(_:)), for: .editingChanged)
            field.enablesReturnKeyAutomatically = true
            field.autocapitalizationType = .words
            field.clearButtonMode = .whileEditing
            field.placeholder = "group name"
            field.returnKeyType = .done
            field.tintColor = .systemBlue
        }
        ac.addTextField { field in
            field.addTarget(self, action: #selector(self.textFieldDidChange(_:)), for: .editingChanged)
            field.enablesReturnKeyAutomatically = true
            field.autocapitalizationType = .words
            field.clearButtonMode = .whileEditing
            field.placeholder = "first user"
            field.returnKeyType = .done
            field.tintColor = .systemBlue
        }
        ac.addTextField { field in
            field.addTarget(self, action: #selector(self.textFieldDidChange(_:)), for: .editingChanged)
            field.enablesReturnKeyAutomatically = true
            field.autocapitalizationType = .words
            field.clearButtonMode = .whileEditing
            field.placeholder = "second user"
            field.returnKeyType = .done
            field.tintColor = .systemBlue
        }
        
        let createAction = UIAlertAction(title: "Create", style: .default, handler: { _ in
            self.createGroupChatRoom()
        })
        createAction.isEnabled = false
        ac.addAction(createAction)
        ac.preferredAction = createAction
        
        present(ac, animated: true) {
            ac.textFields?.first?.becomeFirstResponder()
        }
        createNewMessageAlertController = ac
    }
    
    
    
    @objc private func textFieldDidChange(_ field: UITextField) {
        guard let ac = createNewMessageAlertController else {
            return
        }
        
        ac.preferredAction?.isEnabled = field.hasText
    }
    
    private func createChatRoom() {
        guard let ac = createNewMessageAlertController else {
            return
        }
        
        guard let chatRoomName = ac.textFields?.first?.text else {
            return
        }
        
        if chatRoomName.lowercased() == user?.name.lowercased() {
            self.alert(message: "Your chatroom name cannot be same as your username.")
            return
        }
        
        
        let previousChat = chatMessages.filter{ $0.name == chatRoomName }
        
        if previousChat.count > 0 {
            let chatRoom = previousChat.first
            let vc = ViewController()
            vc.user = user
            vc.chatRoom = chatRoom
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else {
            var chatRoom = ChatRoom(name: chatRoomName)
            var ref: DocumentReference? = nil
            ref = reference?.addDocument(data: chatRoom.dictionary) { error in
                if let e = error {
                    print("Error saving chat room: \(e.localizedDescription)")
                }
                chatRoom.id = ref?.documentID
                let vc = ViewController()
                vc.user = self.user
                vc.chatRoom = chatRoom
                self.navigationController?.pushViewController(vc, animated: true)
                return
            }
        }
    }
    
    private func createGroupChatRoom() {
        guard let ac = createNewMessageAlertController else {
            return
        }
        
        guard let chatRoomName = ac.textFields?.first?.text else {
            return
        }
        guard let firstUser = ac.textFields?[1].text else {
            return
        }
        
        guard let secondUser = ac.textFields?[2].text else {
            return
        }
        
        if chatRoomName.lowercased() == user?.name.lowercased() {
            self.alert(message: "Your chatroom name cannot be same as your username.")
            return
        }
        
        
        let previousChat = chatMessages.filter{ $0.name == chatRoomName }
        
        if previousChat.count > 0 {
            let chatRoom = previousChat.first
            let vc = ViewController()
            vc.user = user
            vc.chatRoom = chatRoom
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else {
            let groupUsers = [self.user?.name,firstUser,secondUser]
            guard let groupString = json(from: groupUsers)  else {
                return
            }
            var chatRoom = ChatRoom(name: chatRoomName,groupUsers:  groupString )
            var ref: DocumentReference? = nil
            ref = reference?.addDocument(data: chatRoom.dictionary) { error in
                if let e = error {
                    print("Error saving chat room: \(e.localizedDescription)")
                }
                chatRoom.id = ref?.documentID
                let vc = ViewController()
                vc.user = self.user
                vc.chatRoom = chatRoom
                self.navigationController?.pushViewController(vc, animated: true)
                return
            }
        }
    }
    
    func json(from object:Any) -> String? {
        guard let data = try? JSONSerialization.data(withJSONObject: object, options: []) else {
            return nil
        }
        return String(data: data, encoding: String.Encoding.utf8)
    }
    
    private func handleDocumentChange(_ change: DocumentChange) {
        guard let chatRoom = ChatRoom(document: change.document) else {
            return
        }
        
        switch change.type {
        case .added:
            addChatRoom(chatRoom)
            
        case .modified:
            updateChatRoom(chatRoom)
            
        case .removed:
            removeChatRoom(chatRoom)
        }
    }
    
    private func addChatRoom(_ chatRoom: ChatRoom) {
        guard !chatMessages.contains(chatRoom) else {
            return
        }
        
        chatMessages.append(chatRoom)
        chatMessages.sort()
        
        guard let index = chatMessages.index(of: chatRoom) else {
            return
        }
        chatTableView.tableView.insertRows(at: [IndexPath(row: index, section: 0)], with: .automatic)
    }
    
    private func updateChatRoom(_ chatRoom: ChatRoom) {
        guard let index = chatMessages.index(of: chatRoom) else {
            return
        }
        
        chatMessages[index] = chatRoom
        chatTableView.tableView.reloadRows(at: [IndexPath(row: index, section: 0)], with: .automatic)
    }
    
    private func removeChatRoom(_ chatRoom: ChatRoom) {
        guard let index = chatMessages.index(of: chatRoom) else {
            return
        }
        
        chatMessages.remove(at: index)
        chatTableView.tableView.deleteRows(at: [IndexPath(row: index, section: 0)], with: .automatic)
    }
    
    
    func alert(message:String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

extension ChatRoomViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return chatMessages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "chatRoomCell", for: indexPath) as? ChatRoomCell else { return UITableViewCell() }
        cell.selectionStyle = .none
        cell.chatMessage = chatMessages[indexPath.row]
        return cell
    }
}

extension ChatRoomViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let chatRoom = chatMessages[indexPath.row]
        let vc = ViewController()
        vc.user = user
        vc.chatRoom = chatRoom
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
