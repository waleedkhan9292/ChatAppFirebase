//
//  ViewController.swift
//  ChatApp
//
//  Created by Waleed Waheed Khan on 5/25/20.
//  Copyright © 2020 Waleed Waheed Khan. All rights reserved.
//

import UIKit
import Firebase
import FirebaseFirestore

public struct Sender {
    public let id: String
    public let displayName: String
    
    // MARK: - Intializers
    public init(id: String, displayName: String) {
        self.id = id
        self.displayName = displayName
    }
}

public enum MessageData {
    case text(String)
}

extension Sender: Equatable {
    public static func == (left: Sender, right: Sender) -> Bool {
        return left.id == right.id
    }
}

public protocol MessageType {
    var sender: Sender { get }
    var messageId: String { get }
    var sentDate: Date { get }
    var data: MessageData { get }
}

struct Message: MessageType {
    
    let id: String?
    let content: String
    let sentDate: Date
    let sender: Sender
    
    var data: MessageData {
        return .text(content)
    }
    
    var messageId: String {
        return id ?? UUID().uuidString
    }
    
    init(userName: String, content: String) {
        sender = Sender(id: userName, displayName: userName)
        self.content = content
        sentDate = Date()
        id = nil
    }
    
    init?(document: QueryDocumentSnapshot) {
        let data = document.data()
        
        guard let sentDate = data["created"] as? Timestamp else {
            return nil
        }
        guard let senderID = data["senderID"] as? String else {
            return nil
        }
        guard let senderName = data["senderName"] as? String else {
            return nil
        }
        
        id = document.documentID
        
        self.sentDate = Date()//sentDate
        sender = Sender(id: senderID, displayName: senderName)
        
        if let content = data["content"] as? String {
            self.content = content
        } else {
            return nil
        }
    }
    
}

extension Message: Dictionary {
    
    var dictionary: [String : Any] {
        var data: [String : Any] = [
            "created": sentDate,
            "senderID": sender.id,
            "senderName": sender.displayName
        ]
        data["content"] = content
        
        return data
    }
    
}

extension Message: Comparable {
    
    static func == (lhs: Message, rhs: Message) -> Bool {
        return lhs.id == rhs.id
    }
    
    static func < (lhs: Message, rhs: Message) -> Bool {
        return lhs.sentDate < rhs.sentDate
    }
    
}


class ViewController: UIViewController {
    
    private let db = Firestore.firestore()
    private var reference: CollectionReference?
    
    private var messageListener: ListenerRegistration?
    
    var user: User?
    var chatRoom: ChatRoom? = nil
    
    let chatTableView = ChatTableView()
    
    var chatMessages: [Message] = []
    
    deinit {
        messageListener?.remove()
    }
    
    override func loadView() {
        view = chatTableView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setTableView()
        chatTableView.viewController = self
        
        guard let id = chatRoom?.id else {
            navigationController?.popViewController(animated: true)
            return
        }
        
        guard let userId = user?.id else {
            navigationController?.popViewController(animated: true)
            return
        }
        self.title = chatRoom?.name
        reference = db.collection(["user", userId, "channel", id, "thread"].joined(separator: "/"))
        messageListener = reference?.addSnapshotListener { querySnapshot, error in
            guard let snapshot = querySnapshot else {
                print("Error listening for chat room updates: \(error?.localizedDescription ?? "No error")")
                return
            }
            
            snapshot.documentChanges.forEach { change in
                self.handleDocumentChange(change)
            }
        }
    }
    
    @objc func sendMessage() {
        let content = self.chatTableView.messageTextField.text ?? ""
        self.chatTableView.messageTextField.text = ""
        let message = Message(userName: user?.name ?? "", content: content)
        self.save(message)
        
        guard let chatRoomName = self.chatRoom?.name else {
            return
        }
        if let groupUsersString = self.chatRoom?.groupUsers {
            guard let groupUsers = convertToDictionary(text: groupUsersString) as? [String] else {
                return
            }
            for user in groupUsers {
                if user != self.user?.name {
                    self.find(user, chatRoomName, true, message)
                }
            }
        }
        else {
            
            guard let chatRoomUsername = self.user?.name else { return }
            self.find(chatRoomName, chatRoomUsername, false, message)
        }
    }
    
}

extension ViewController {
    func setTableView() {
        chatTableView.tableView.dataSource = self
        chatTableView.tableView.separatorStyle = .none
        
        chatTableView.tableView.register(IncommingMessageCell.self, forCellReuseIdentifier: "incommingMessageCell")
        
        chatTableView.tableView.register(OutgoingMessageCell.self, forCellReuseIdentifier: "outgoingMessageCell")
    }
    
    func find(_ chatRoomName: String,_ chatRoomUsername: String,_ isGroup: Bool,_ message: Message) {
        var found = false
        db.collection("user").getDocuments { querySnapshot, error in
            guard let snapshot = querySnapshot else {
                print("Error listening for chat room updates: \(error?.localizedDescription ?? "No error")")
                return
            }

            
            snapshot.documentChanges.forEach { change in
                
                let data = change.document.data()
                if let userName = data["userName"] as? String {
                    if userName.lowercased() == chatRoomName.lowercased() {
                        found = true
                        self.getChatRoom(change.document.documentID, chatRoomUsername, isGroup, message)
                    }
                }
            }
            if !found {
                self.alert(message: "User not found.")
            }
        }
    }
    
    func convertToDictionary(text: String) -> Any? {

         if let data = text.data(using: .utf8) {
             do {
                 return try JSONSerialization.jsonObject(with: data, options: []) as? Any
             } catch {
                 print(error.localizedDescription)
             }
         }

         return nil
    }
    
    private func getChatRoom(_ userDocumentID: String,_ chatRoomUsername: String,_ isGroup: Bool,_ message: Message) {
        
        var found = false
        self.db.collection(["user", userDocumentID, "channel"].joined(separator: "/")).getDocuments { querySnapshot, error in
            guard let snapshot = querySnapshot else {
                print("Error listening for chat room updates: \(error?.localizedDescription ?? "No error")")
                return
            }
            snapshot.documentChanges.forEach { change in
                
                let data = change.document.data()
                if let userName = data["name"] as? String {
                    if userName.lowercased() == chatRoomUsername.lowercased() {
                        found = true
                        self.addChatInChatRoom(userDocumentID, change.document.documentID, message)
                    }
                }
            }
            if !found {
                guard let name = self.user?.name else {
                    return
                }
                var room: ChatRoom?
                if isGroup {
                    room = self.chatRoom
                }
                else {
                    room = ChatRoom(name: name)
                }
                
                var ref: DocumentReference? = nil
                ref = self.db.collection(["user", userDocumentID, "channel"].joined(separator: "/")).addDocument(data: room!.dictionary) { error in
                    if let e = error {
                        print("Error sending message: \(e.localizedDescription)")
                        return
                    }
                    guard let documentID = ref?.documentID else {
                        return
                    }
                    self.addChatInChatRoom(userDocumentID, documentID, message)
                }
            }
        }
    }
    
    private func addChatInChatRoom(_ userDocumentID: String,_  chatRoomDocumentID: String,_ message: Message) {
        
//        let message = Message(userName: user?.name ?? "", content: self.chatTableView.messageTextField.text ?? "")
        self.db.collection(["user", userDocumentID, "channel",chatRoomDocumentID, "thread" ].joined(separator: "/")).addDocument(data: message.dictionary) { error in
            if let e = error {
                print("Error sending message: \(e.localizedDescription)")
                return
            }

//            self.save(message)
        }
        
    }
    
    private func save(_ message: Message) {
        reference?.addDocument(data: message.dictionary) { error in
            if let e = error {
                print("Error sending message: \(e.localizedDescription)")
                return
            }
            
//            self.chatTableView.messageTextField.text = ""
            self.scrollToBottom()
        }
    }
    
    private func insertNewMessage(_ message: Message) {
        guard !chatMessages.contains(message) else {
            return
        }
        
        chatMessages.append(message)
        chatMessages.sort()
        
        let isLatestMessage = chatMessages.index(of: message) == (chatMessages.count - 1)
        let shouldScrollToBottom = chatTableView.tableView.isAtBottom && isLatestMessage
        
        chatTableView.tableView.reloadData()
        
        if shouldScrollToBottom {
            DispatchQueue.main.async {
                self.scrollToBottom(animated: true)
            }
        }
    }
    
    private func handleDocumentChange(_ change: DocumentChange) {
        guard let message = Message(document: change.document) else {
            return
        }
        
        switch change.type {
        case .added:
            insertNewMessage(message)
            
        default:
            break
        }
    }
    
    public func scrollToBottom(animated: Bool = false) {
        let collectionViewContentHeight = chatTableView.tableView.contentSize.height
        
        chatTableView.tableView.performBatchUpdates(nil) { _ in
            self.chatTableView.tableView.scrollRectToVisible(CGRect(x: 0.0, y: collectionViewContentHeight - 1.0, width: 1.0, height: 1.0), animated: animated)
        }
    }
    
    func alert(message:String) {
        let alert = UIAlertController(title: "Error: Couldnot send message.", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return chatMessages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if chatMessages[indexPath.row].sender.id == user?.name {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "outgoingMessageCell", for: indexPath) as? OutgoingMessageCell else {
                return UITableViewCell()
            }
            cell.selectionStyle = .none
            cell.chatMessage = chatMessages[indexPath.row]
            return cell
        }
        else {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "incommingMessageCell", for: indexPath) as? IncommingMessageCell else {
                return UITableViewCell()
            }
            cell.selectionStyle = .none
            cell.chatMessage = chatMessages[indexPath.row]
            return cell
        }
    }
}

extension UIScrollView {
    
    var isAtBottom: Bool {
        return contentOffset.y >= verticalOffsetForBottom
    }
    
    var verticalOffsetForBottom: CGFloat {
        let scrollViewHeight = bounds.height
        let scrollContentSizeHeight = contentSize.height
        let bottomInset = contentInset.bottom
        let scrollViewBottomOffset = scrollContentSizeHeight + bottomInset - scrollViewHeight
        return scrollViewBottomOffset
    }
    
}
